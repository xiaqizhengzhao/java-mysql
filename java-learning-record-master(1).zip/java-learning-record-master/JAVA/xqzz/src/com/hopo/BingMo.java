package com.hopo;

import java.util.Scanner;

public class BingMo {
    public static void main(String[] args) {
/*        byte integer1 = 127;
        short integer2 = 356;
        int integer3 = 222;
        long integer4 = 3333L;
        float floating1 = 1.1f;
        double floating2 = 4.222;
        System.out.println(integer1);
        System.out.println(integer2);
        System.out.println(integer3);
        System.out.println(integer4);
        System.out.println(floating1);
        System.out.println(floating2);
        boolean example0 = false;
        boolean example1 =true;
        String example2 ="你好";
        System.out.println(example2);*/
/*        String s1 = "欢迎来到湖南株洲";
        String s2 = "姓名：李四";
        String s3 = "年龄：20";
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);*/
/*        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入整数");
        int i=scanner.nextInt();
        System.out.println("你输入的整数是："+i);*/
        /*Scanner scanner = new Scanner(System.in);
        System.out.println("请输入姓名：");
        String xingmi = scanner.nextLine();
        System.out.println("请输入年龄：");
        int nianli = scanner.nextInt();
        System.out.println("请输入体重");
        double tizhong = scanner.nextDouble();
        System.out.println("我的姓名是："+xingmi);
        System.out.println("我的年龄是："+nianli);
        System.out.println("我的体重是："+tizhong);*/
        Scanner scanner = new Scanner(System.in);
        System.out.println("欢迎光临蓝梦音乐网");
        System.out.println("请输入用户名");
        String name = scanner.nextLine();
        System.out.println("请输入密码");
        String mm = scanner.nextLine();
        System.out.println("用户名为："+name);
        System.out.println("密码为："+mm);
    }
}
